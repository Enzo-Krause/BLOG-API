
package com.api.blog.postController;

import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.api.blog.dto.request.ComentarioRequestDto;
import com.api.blog.dto.request.PostRequest;
import com.api.blog.dto.request.comentarioresponseDto;
import com.api.blog.dto.response.PostResposta;
import com.api.blog.service.PostService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(name = "Posts e comentarios", description = "Operações do Blog API")
@RestController
@RequestMapping("/api")
public class PostController {

    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @Operation(summary = "Lista posts com paginação", description = "Retorna uma lista contendo todos os posts cadastrados no blog.")
    @GetMapping("/posts")
    public ResponseEntity<Page<PostResposta>> getAllPost(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "data") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sort = direction.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(page, size, sort);

        return ResponseEntity.ok(postService.findAll(pageable));
    }

    @Operation(summary = "Busca um post pelo ID", description = "Retorna um post específico utilizando seu ID.")
    @GetMapping("/posts/{id}")
    public ResponseEntity<PostResposta> getPostById(@PathVariable UUID id) {
        return ResponseEntity.ok(postService.findById(id));
    }

    @Operation(summary = "Cria um novo post", description = "Cadastra um novo post no blog.")
    @PostMapping("/newpost")
    public ResponseEntity<PostResposta> createPost(
            @RequestBody @Valid PostRequest dto) {

        PostResposta created = postService.save(dto);

        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @Operation(summary = "Edita um post")
    @PutMapping("/editapost/{id}")
    public ResponseEntity<PostResposta> editPost(
            @PathVariable UUID id,
            @RequestBody @Valid PostResposta dto) {

        return ResponseEntity.ok(postService.Edit(id, dto));
    }

    @Operation(summary = "Exclui um post")
    @DeleteMapping("/deletapost/{id}")
    public ResponseEntity<Void> deletePost(@PathVariable UUID id) {

        postService.delet(id);

        return ResponseEntity.noContent().build();
    }

    @PostMapping("/comentarios/{postId}")
    public ResponseEntity<comentarioresponseDto> createComentario(
            @PathVariable UUID postId,
            @RequestBody @Valid ComentarioRequestDto dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(postService.addComentario(postId, dto));
    }

    @PostMapping("/comentarios/edit{postId}")
    public ResponseEntity<comentarioresponseDto> editComentario(
            @PathVariable UUID postId,
            @RequestBody @Valid ComentarioRequestDto dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(postService.addComentario(postId, dto));
    }

    @PostMapping("/comentarios/delete/{postId}")
    public ResponseEntity<comentarioresponseDto> deleteComentario(
            @PathVariable UUID postId,
            @RequestBody @Valid ComentarioRequestDto dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(postService.addComentario(postId, dto));
    }
}

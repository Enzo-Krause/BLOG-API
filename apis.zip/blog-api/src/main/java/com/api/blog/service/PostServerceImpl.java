
package com.api.blog.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.api.blog.dto.request.ComentarioRequestDto;
import com.api.blog.dto.request.PostRequest;
import com.api.blog.dto.request.comentarioresponseDto;
import com.api.blog.dto.response.ComentarioRepository;
import com.api.blog.dto.response.PostResposta;
import com.api.blog.mapper.PoatMapper;
import com.api.blog.mapper.comentarioMapper;
import com.api.blog.model.PostModel;
import com.api.blog.model.comentarioModel;
import com.api.blog.repository.PostRepository;

@Service
public class PostServerceImpl implements PostService {

	private final PostRepository postRepository;
	private final PoatMapper poatMapper;
	private final comentarioMapper comentarioMapper;
	private final ComentarioRepository ComentarioRepository;

	public PostServerceImpl(PostRepository postRepository, PoatMapper poatMapper,
			ComentarioRepository ComentarioRepository, comentarioMapper comentarioMapper) {

		this.postRepository = postRepository;
		this.poatMapper = poatMapper;
		this.ComentarioRepository = ComentarioRepository;
		this.comentarioMapper = comentarioMapper;
	}

	@Override
	public PostResposta save(PostRequest postRequest) {

		PostModel post = poatMapper.toEntity(postRequest);

		PostModel postSaved = postRepository.save(post);

		return poatMapper.toDto(postSaved);
	}

	@Override
	public PostResposta createPost(PostRequest dto) {
		return save(dto);
	}

	@Override
	@Transactional
	public Page<PostResposta> findAll(Pageable pageable) {

		Page<PostModel> posts = postRepository.findAll(pageable);

		return posts.map(poatMapper::toDto);
	}

	@Override
	@Transactional(readOnly = true)
	public Page<PostResposta> findAll(Pageable pageable, String titulo) {

		Page<PostModel> posts;

		if (titulo == null || titulo.isBlank()) {
			posts = postRepository.findByTituloContainingIgnoreCase(titulo, pageable);
		} else {
			posts = postRepository.findByTituloContainingIgnoreCase(titulo, pageable);
		}

		List<PostResposta> resposta = new ArrayList<>();

		for (PostModel post : posts.getContent()) {
			PostResposta dto = poatMapper.toDto(post);
			resposta.add(dto);
		}

		return new PageImpl<>(resposta, pageable, posts.getTotalElements());
	}

	@Override
	public PostResposta findById(UUID id) {

		return postRepository.findById(id).map(poatMapper::toDto)
				.orElseThrow(() -> new RuntimeException("Post não encontrado"));
	}

	@Override
	public PostResposta delet(UUID id) {

		PostModel post = postRepository.findById(id).orElseThrow(() -> new RuntimeException("Post não encontrado"));

		PostResposta resposta = poatMapper.toDto(post);

		postRepository.delete(post);

		return resposta;
	}

	@Override
	public PostResposta Edit(UUID id, PostResposta dto) {

		PostModel post = postRepository.findById(id).orElseThrow(() -> new RuntimeException("Post não encontrado"));

		post.setAutor(dto.autor());
		post.setTitulo(dto.titulo());
		post.setTexto(dto.texto());

		PostModel atualizado = postRepository.save(post);

		return poatMapper.toDto(atualizado);
	}

	@Override
	@Transactional
	public comentarioresponseDto addComentario(UUID postId, ComentarioRequestDto dto) {

		PostModel post = postRepository.findById(postId).orElseThrow(() -> new RuntimeException("Post não encontrado"));

		comentarioModel comentario = comentarioMapper.toEntity(dto, post);

		post.adicionarComentario(comentario);

		ComentarioRepository.save(comentario);

		return comentarioMapper.toDto(comentario);
	}

	@Override
	public comentarioresponseDto DeleteC(UUID postId) {

		if (ComentarioRepository.findById(postId).isPresent()) {

			comentarioModel comentario = ComentarioRepository.findById(postId).get();

			ComentarioRepository.delete(comentario);

		} else {
			throw new RuntimeException("Id nao identificado");
		}

		return null;
	}

	@Override
	public comentarioresponseDto EditC(UUID postId, ComentarioRequestDto dto) {

		if (ComentarioRepository.findById(postId).isPresent()) {

			comentarioModel comentario = ComentarioRepository.findById(postId).get();

			comentario.setComentario(dto.comentario());

			ComentarioRepository.save(comentario);

			return comentarioMapper.toDto(comentario);

		} else {
			throw new RuntimeException("Id nao identificado");
		}
	}
}

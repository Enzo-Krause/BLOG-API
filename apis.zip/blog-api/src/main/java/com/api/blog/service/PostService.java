
package com.api.blog.service;

import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.api.blog.dto.request.ComentarioRequestDto;
import com.api.blog.dto.request.PostRequest;
import com.api.blog.dto.request.comentarioresponseDto;
import com.api.blog.dto.response.PostResposta;

public interface PostService {

    Page<PostResposta> findAll(Pageable pageable);

    Page<PostResposta> findAll(Pageable pageable, String titulo);

    PostResposta findById(UUID id);

    PostResposta delet(UUID id);

    PostResposta Edit(UUID id, PostResposta dto);

    PostResposta createPost(PostRequest dto);

    comentarioresponseDto addComentario(
            UUID postId, ComentarioRequestDto dto);

    PostResposta save(PostRequest postRequest);

    comentarioresponseDto DeleteC(UUID comentarioId);

    comentarioresponseDto EditC(
            UUID comentarioId, ComentarioRequestDto dto);
}
